from itertools import combinations

import networkx as nx
import pandas as pd

from dataManager.load_metaData import *
from dataManager.load_marketData import *

def extract_signal_from_nx_centrality(date="20210727"):
    tradingDayCalender_list = load_tradingDayCalender_list()
    ix = tradingDayCalender_list.index(date)
    tradingDayCalender_list = tradingDayCalender_list[:ix]
    kospi200Issuecode2name_dict = load_kospi200Issuecode2name_dict()
    issuecode2retList_dict = dict()
    for issuecode in sorted(kospi200Issuecode2name_dict):
        date2ret_dict = load_date2ret_dict(issuecode)
        ret_list = list()
        for date in tradingDayCalender_list:
            ret_list.append(date2ret_dict[date])
        issuecode2retList_dict[kospi200Issuecode2name_dict[issuecode]] = ret_list
    issuecode2retList_dict["date"] = tradingDayCalender_list
    df = pd.DataFrame(issuecode2retList_dict).set_index('date')
    corr_df = df.corr()
    G = nx.Graph()
    for stock_pair in combinations(corr_df.columns, 2):
        abs_corr = abs(corr_df[stock_pair[0]][stock_pair[1]])
        G.add_weighted_edges_from([(stock_pair[0], stock_pair[1], abs_corr)])
        
    #bet_centrality_dict = nx.betweenness_centrality(G,weight='weight')
    #sorted_list = sorted(bet_centrality_dict.items(), key=lambda kv: -kv[1])
    #print(sorted_list)

    closeness_centrality_dict = nx.closeness_centrality(G, distance='weight')
    sorted_list = sorted(closeness_centrality_dict.items(), key=lambda kv: -kv[1])
    #print(sorted_list)

    return sorted_list


    pagerank_dict = nx.pagerank(G)
    sorted_list = sorted(pagerank_dict.items(), key=lambda kv: -kv[1])
    print(sorted_list)

    harmonic_dict = nx.harmonic_centrality(G,distance='weight')
    sorted_list = sorted(harmonic_dict.items(), key=lambda kv: -kv[1])
    print(sorted_list)
    return sorted_list


if __name__ == "__main__":
    extract_signal_from_nx_centrality()

