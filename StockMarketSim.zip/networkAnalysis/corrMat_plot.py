import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

plt.rcParams['axes.unicode_minus'] = False

from matplotlib import font_manager, rc
import platform

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print('Unknown system... sorry~~~~')

from dataManager.load_metaData import *
from dataManager.load_marketData import *


def plot_corrMat_KOSPI30():
    tradingDayCalender_list = load_tradingDayCalender_list()
    kospi30Issuecode2name_dict = load_kospi30Issuecode2name_dict()
    issuecode2retList_dict = dict()
    for issuecode in sorted(kospi30Issuecode2name_dict):
        date2ret_dict = load_date2ret_dict(issuecode)
        ret_list = list()
        for date in (tradingDayCalender_list):
            ret_list.append(date2ret_dict[date])
        issuecode2retList_dict[kospi30Issuecode2name_dict[issuecode]] = ret_list
    issuecode2retList_dict["date"] = tradingDayCalender_list
    df = pd.DataFrame(issuecode2retList_dict).set_index('date')
    plotCorrMat(df)

def plotCorrMat(df,method = 'pearson'):
    corr = df.corr(method = method)
    #mask = np.zeros_like(corr, dtype=np.bool)
    #mask[np.triu_indices_from(mask)] = True

    # Set up the matplotlib figure
    fig, ax = plt.subplots(figsize=(15, 15))
    # Generate a custom diverging colormap
    mask = np.triu(np.ones_like(corr, dtype=bool))
    cmap = sns.diverging_palette(220, 10, as_cmap=True)
    # Draw the heatmap with the mask and correct aspect ratio

    heatmap = sns.heatmap(corr,ax=ax,mask=mask, vmin=-1, vmax=1, annot=True,cmap=cmap,center=0.,fmt = ".2f")#, vmax=.3, ,

    fig.savefig("corr_mat.png",dpi=300)
    plt.show()
    return

if __name__ == "__main__":
    plot_corrMat_KOSPI30()

