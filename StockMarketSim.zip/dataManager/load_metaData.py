import pathlib
from os.path import realpath, join

file_path = realpath(__file__)
_ABS_path_parts_file = pathlib.Path(file_path).absolute().parts
_SRC_DIR_PATH = join(*_ABS_path_parts_file[:-1])


def load_kospi200Issuecode2name_dict():
    "http://www.pharmstock.co.kr/news/articleView.html?idxno=489"
    result_dict = dict()
    with open(join(_SRC_DIR_PATH, "KOSPI200_20210104.csv"),'r') as f:
        f.readline()
        for num, line in enumerate(f):
            issuecode, stock_name, *rest = line.rstrip("\n").split(",")
            result_dict[issuecode] = stock_name
    return result_dict

def load_stockname2kospi200Issuecode_dict():
    "http://www.pharmstock.co.kr/news/articleView.html?idxno=489"
    result_dict = dict()
    with open(join(_SRC_DIR_PATH, "KOSPI200_20210104.csv"),'r') as f:
        f.readline()
        for num, line in enumerate(f):
            issuecode, stock_name, *rest = line.rstrip("\n").split(",")
            result_dict[stock_name] = issuecode
    return result_dict

def load_kospi30Issuecode2name_dict():
    "http://www.pharmstock.co.kr/news/articleView.html?idxno=489"
    result_dict = dict()
    with open(join(_SRC_DIR_PATH, "KOSPI200_20210104.csv"),'r') as f:
        f.readline()
        for num, line in enumerate(f):
            if num > 30:
                continue
            issuecode, stock_name, *rest = line.rstrip("\n").split(",")
            result_dict[issuecode] = stock_name
    return result_dict

def load_tradingDayCalender_list():
    result_list = list()
    with open(join(_SRC_DIR_PATH,"tradingDay_calender.csv"), "r") as f:
        for line in f:
            result_list.append(line.rstrip("\n"))
    return list(reversed(result_list))

