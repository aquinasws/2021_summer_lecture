import pathlib
from os.path import realpath, join

file_path = realpath(__file__)
_ABS_path_parts_file = pathlib.Path(file_path).absolute().parts

def load_issuecode2px_dict(issuecode="005930"):
    result_dict = dict()
    px_dir_path = join(*_ABS_path_parts_file[:-1], "..", "data", "px_data")
    issuecode_px_file_path = join(px_dir_path,issuecode + ".csv")
    with open(issuecode_px_file_path, "r") as f:
        for line in f:
            date, px = line.rstrip("\n").split(",")
            result_dict[date.replace(".","")] = float(px)
    return result_dict

def load_date2ret_dict(issuecode="005930"):
    result_dict = dict()
    px_dir_path = join(*_ABS_path_parts_file[:-1], "..", "data", "px_data")
    issuecode_px_file_path = join(px_dir_path,issuecode + ".csv")
    with open(issuecode_px_file_path, "r") as f:
        px_prev = float(f.readline().rstrip("\n").split(",")[1])
        for line in f:
            date, px = line.rstrip("\n").split(",");px = float(px)
            result_dict[date.replace(".","")] = (px - px_prev)/px_prev
            px_prev = px
    return result_dict
