import numpy as np
import time

def cal_perf_dict(size_of_haystack=1000):
    n_needles = 10000000
    needles_array = np.arange(n_needles)

    size_sample = int(size_of_haystack/2)
    haystack = np.random.choice(needles_array, size_sample, replace=False)
    haystack = np.concatenate((haystack, np.arange(n_needles, n_needles + size_sample)))
    haystack_dict = dict.fromkeys(haystack)
    #haystack_list = list(haystack)

    t = time.time()
    found = 0
    for needle in needles_array:
        if needle in haystack_dict:
            found += 1
    print(found)
    print("elapsed time:", time.time() - t)


def comp_dict_perf():
    size_haystack_list = [1000, 10000, 100000, 1000000, 10000000]
    for size_haystack in size_haystack_list:
        print("size_haystack:", size_haystack,end=", ")
        cal_perf_dict(size_haystack)


if __name__ == "__main__":
    cal_perf_dict()
    #comp_dict_perf()