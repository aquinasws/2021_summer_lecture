import os

import numpy as np

from networkAnalysis.main import *

file_path = realpath(__file__)
_ABS_path_parts_file = pathlib.Path(file_path).absolute().parts
_SRC_DIR_PATH = join(*_ABS_path_parts_file[:-1])

def sim():
    tradingDayCalender_list = load_tradingDayCalender_list()
    stockname2kospi200Issuecode_dict = load_stockname2kospi200Issuecode_dict()
    kospi200Issuecode2name_dict = load_kospi200Issuecode2name_dict()

    date2_issuecode2ret_dict = {date:dict() for date in tradingDayCalender_list}
    for issuecode in sorted(kospi200Issuecode2name_dict):
        date2ret_dict = load_date2ret_dict(issuecode)
        for date in tradingDayCalender_list:
            date2_issuecode2ret_dict[date][issuecode] = date2ret_dict[date]
    pos_dir_path = join(_SRC_DIR_PATH, "pos")
    pos_filename_list = [filename for filename in os.listdir(pos_dir_path)]
    market_ret_cum = 1
    portfolio_ret_cum = 1
    fw = open("ret_profile.csv", "w")
    fw.write("date,market_ret,portfolio_ret,market_ret_cum,portfolio_ret_cum\n")
    for pos_filename in pos_filename_list:
        date = pos_filename[:-4]
        fw.write(date+",")
        issuecode2ret_dict = date2_issuecode2ret_dict[date]
        portfolio_ret_list = list()
        market_ret_list = list()
        with open(join(pos_dir_path,pos_filename), "r") as f:
            for line in f:
                stock_name, pos = line.rstrip("\n").split(",")
                ret = issuecode2ret_dict[stockname2kospi200Issuecode_dict[stock_name]]
                market_ret_list.append(ret)
                if pos == "1": portfolio_ret_list.append(ret)
        print(date)
        market_ret_ave = np.average(market_ret_list)
        portfolio_ret_ave = np.average(portfolio_ret_list)
        print("market_ret:", market_ret_ave )
        print("portfolio_ret:", portfolio_ret_ave)
        market_ret_cum *= 1 + market_ret_ave
        portfolio_ret_cum *= 1 + portfolio_ret_ave
        print("market_ret_cum:", market_ret_cum-1)
        print("portfolio_ret_cum:", portfolio_ret_cum-1)
        fw.write(f"{market_ret_ave},{portfolio_ret_ave},{market_ret_cum-1},{portfolio_ret_cum-1}\n")
        print()
    fw.close()





sim()