import os

from networkAnalysis.main import *

file_path = realpath(__file__)
_ABS_path_parts_file = pathlib.Path(file_path).absolute().parts
_SRC_DIR_PATH = join(*_ABS_path_parts_file[:-1])

def dump_pos():
    pos_dir_path = join(_SRC_DIR_PATH, "pos")
    pos_filename_list = [filename for filename in os.listdir(pos_dir_path)]
    for filename in pos_filename_list: os.remove(join(pos_dir_path, filename))
    kospi200Issuecode2name_dict = load_kospi200Issuecode2name_dict()
    stockname2kospi200Issuecode_dict = load_stockname2kospi200Issuecode_dict()
    tradingDayCalender_list = load_tradingDayCalender_list()
    training_period = 100
    for num, date in enumerate(tradingDayCalender_list):
        if num < training_period: continue
        training_period_list = tradingDayCalender_list[:num]
        date_end = training_period_list[-1]
        signal_from_nx_centrality = extract_signal_from_nx_centrality(date=date_end)
        ##
        target_stockIssuecode_set = set([stockname2kospi200Issuecode_dict[elt[0]] for elt in signal_from_nx_centrality[:10]])
        with open(join(pos_dir_path, date_end + ".csv"), "w") as f:
            for issuecode in sorted(kospi200Issuecode2name_dict):
                if issuecode in target_stockIssuecode_set: pos = 1
                else: pos = 0
                f.write(f"{kospi200Issuecode2name_dict[issuecode]},{pos}\n")
        print(date," pos is dummped")

main()


