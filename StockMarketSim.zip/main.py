from os.path import join
import time


from selenium import webdriver
from bs4 import BeautifulSoup


chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("headless")
_DRIVER = webdriver.Chrome('chromedriver.exe', chrome_options=chrome_options)

def load_kospi2002issuecode2name_dict():
    result_dict = dict()
    with open("KOSPI200_20210104.csv",'r') as f:
        f.readline()
        for line in f:
            issuecode, stock_name, *rest = line.rstrip("\n").split(",")
            result_dict[issuecode] = stock_name
    return result_dict

def main():
    dst_dir_path = join("px_data")
    kospi2002issuecode2name_dict = load_kospi2002issuecode2name_dict()
    for cnt, issuecode in enumerate(kospi2002issuecode2name_dict.keys()):
        date_px_list = list()
        t = time.time()
        for i in range(1, 100):
            URL_format = f"https://finance.naver.com/item/frgn.nhn?code={issuecode}&page={i}"
            # (1) Open
            _DRIVER.get("view-source:" + URL_format)
            # (2) Read
            html = _DRIVER.page_source
            # (3) Parse
            ix = html.find("보유율")
            ix_e = html.find("페이지 네비게이션")
            bs_obj = BeautifulSoup(html[ix:ix_e],"html.parser")
            bs_obj = BeautifulSoup(bs_obj.text,"html.parser")
            data_list = (bs_obj.text.split(" "))
            n_data = 0
            for num, elt in enumerate(data_list):
                if elt.startswith("2021."):
                    px = data_list[num+1].replace(",","")
                    # (4) Typecast, Allocate
                    date_px_list.append((elt,px))
                    n_data += 1
            if n_data == 0: break
        date_px_list.reverse()
        dst_file_path = join(dst_dir_path,issuecode + ".csv")
        with open(dst_file_path, "w") as f:
            for elt in date_px_list:
                f.write(",".join(elt) + "\n")
        print(cnt+1, " A" + issuecode, kospi2002issuecode2name_dict[issuecode], "is dumped.")
        print("elapsed time:",time.time()-t)
        print()

if __name__ == "__main__":
    main()
